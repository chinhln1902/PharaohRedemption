Chinese Rocks
https://www.dafont.com/chinese-rocks.font